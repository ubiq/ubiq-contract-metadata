module.exports = require('./contract-map.json')
